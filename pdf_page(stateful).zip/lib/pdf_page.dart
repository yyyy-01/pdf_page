// ignore_for_file: prefer_const_constructors

import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:get/get.dart';
import 'package:flutter_share/flutter_share.dart';

class PdfPage extends StatefulWidget {
  static String id = '/pdfPage';
  @override
  _PdfPageState createState() => _PdfPageState();
}

bool isNightMode = false;

class _PdfPageState extends State<PdfPage> {
  final Completer<PDFViewController> _controller =
      Completer<PDFViewController>();
  String remotePDFpath = "";

  int pages = 0;
  int currentPage = 0;
  bool isReady = false;
  String errorMessage = '';

  @override
  void initState() {
    super.initState();

    Get.arguments['url'] == null
        ? setState(() {
            remotePDFpath = Get.arguments['path'];
            isNightMode = Get.arguments['isNightMode'];
            currentPage = Get.arguments['currentPage'];
          })
        : createFileOfPdfUrl().then((f) {
            setState(() {
              remotePDFpath = f.path;
            });
          });
  }

  Future<File> createFileOfPdfUrl() async {
    Completer<File> completer = Completer();
    print("Start download file from internet!");
    try {
      final url = Get.arguments['url'];
      final filename = url.substring(url.lastIndexOf("/") + 1);
      var request = await HttpClient().getUrl(Uri.parse(url));
      var response = await request.close();
      var bytes = await consolidateHttpClientResponseBytes(response);
      var dir = await getApplicationDocumentsDirectory();
      print("Download files");
      print("${dir.path}/$filename");
      File file = File("${dir.path}/$filename");

      await file.writeAsBytes(bytes, flush: true);
      completer.complete(file);
    } on Exception catch (e) {
      print('Error parsing asset file!');
      Get.defaultDialog(
        title: "Error",
        content: Text(e.toString()),
        confirm: FlatButton(
          onPressed: () {
            Get.back();
            Get.back();
          },
          child: Text('GO BACK'),
        ),
      );
    }

    return completer.future;
  }

  void SelectedItem(BuildContext context, item) async {
    switch (item) {
      case 0:
        print('selected dark mode');
        setState(() {
          isNightMode = !isNightMode;
        });
        Get.back();
        Get.toNamed(
          PdfPage.id,
          arguments: {
            'path': remotePDFpath,
            'isNightMode': isNightMode,
            'currentPage': currentPage,
          },
        );
        break;
      //TODO: share pdf
      // case 1:
      //   print('selected share file');
      //   print(remotePDFpath);
      //   await FlutterShare.shareFile(
      //     title: 'PDF Share',
      //     text: 'Look, I have share my PDF with you.',
      //     filePath: remotePDFpath,
      //   );
      //
      //   break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      appBar: AppBar(
        title: Text("PDF View"),
        actions: [
          PopupMenuButton<int>(
            onSelected: (item) => SelectedItem(context, item),
            itemBuilder: (context) => [
              PopupMenuItem<int>(
                value: 0,
                child: Row(
                  children: [
                    isNightMode
                        ? Icon(Icons.light_mode)
                        : Icon(Icons.dark_mode),
                    isNightMode ? Text("  Light Mode") : Text("  Dark Mode"),
                  ],
                ),
              ),
              //TODO: share pdf
              // PopupMenuItem<int>(
              //   value: 1,
              //   child: Row(
              //     children: const [
              //       Icon(Icons.share),
              //       Text(
              //         "  Share",
              //         style: TextStyle(color: Colors.white),
              //       ),
              //     ],
              //   ),
              // ),
            ],
          ),
        ],
      ),
      body: remotePDFpath.isEmpty
          ? Center(child: CircularProgressIndicator())
          : PDFView(
              filePath: remotePDFpath,
              enableSwipe: true,
              swipeHorizontal: true,
              autoSpacing: false,
              pageFling: true,
              pageSnap: true,
              defaultPage: currentPage,
              fitPolicy: FitPolicy.BOTH,
              nightMode: isNightMode,
              preventLinkNavigation:
                  false, // if set to true the link is handled in flutter
              onRender: (_pages) {
                setState(() {
                  pages = _pages!;
                  isReady = true;
                });
              },
              onError: (error) {
                setState(() {
                  errorMessage = error.toString();
                });
                print(error.toString());
                Get.defaultDialog(
                  title: "Error",
                  content: Text(errorMessage),
                  confirm: FlatButton(
                    color: Colors.redAccent,
                    onPressed: () {
                      Get.back();
                      Get.back();
                    },
                    child: Text('GO BACK'),
                  ),
                );
              },
              onPageError: (page, error) {
                setState(() {
                  errorMessage = '$page: ${error.toString()}';
                });
                print('$page: ${error.toString()}');
                Get.defaultDialog(
                  title: "Error",
                  content: Text(errorMessage),
                  confirm: FlatButton(
                    onPressed: () {
                      Get.back();
                      Get.back();
                    },
                    child: Text('GO BACK'),
                  ),
                );
              },
              onViewCreated: (PDFViewController pdfViewController) {
                _controller.complete(pdfViewController);
              },
              onLinkHandler: (String? uri) {
                print('goto uri: $uri');
              },
              onPageChanged: (int? page, int? total) {
                print('page change: $page/$total');
                setState(() {
                  currentPage = page!;
                });
              },
            ),
      floatingActionButton: FutureBuilder<PDFViewController>(
        future: _controller.future,
        builder: (context, AsyncSnapshot<PDFViewController> snapshot) {
          if (snapshot.hasData) {
            return Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                PdfFloatingActionButton(
                  label: Icon(Icons.first_page),
                  onPressed: () async {
                    currentPage = 0;
                    await snapshot.data!.setPage(currentPage);
                  },
                ),
                PdfFloatingActionButton(
                  label: Icon(Icons.chevron_left),
                  onPressed: () async {
                    currentPage--;
                    await snapshot.data!.setPage(currentPage);
                  },
                ),
                PdfFloatingActionButton(
                  label: Text(" ${currentPage + 1} / $pages "),
                  onPressed: () {},
                ),
                PdfFloatingActionButton(
                  label: Icon(Icons.chevron_right),
                  onPressed: () async {
                    currentPage++;
                    await snapshot.data!.setPage(currentPage);
                  },
                ),
                PdfFloatingActionButton(
                  label: Icon(Icons.last_page),
                  onPressed: () async {
                    currentPage = pages;
                    await snapshot.data!.setPage(currentPage);
                  },
                ),
              ],
            );
          }
          return Container();
        },
      ),
    );
  }
}

class PdfFloatingActionButton extends StatelessWidget {
  Widget label;
  VoidCallback onPressed;

  PdfFloatingActionButton(
      {Key? key, required this.label, required this.onPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton.extended(
      backgroundColor: isNightMode ? Colors.grey : Colors.black54,
      foregroundColor: isNightMode ? Colors.black : Colors.white,
      label: label,
      onPressed: onPressed,
    );
  }
}
