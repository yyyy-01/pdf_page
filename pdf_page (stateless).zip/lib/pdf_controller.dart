import 'package:get/get.dart';

class PdfController extends GetxController {
  bool isNightMode = false;
  int totalPages = 0;
  int currentPage = 0;
  bool isSwipeHorizontal = false;
  String pdfPath = '';

  void setNightMode() {
    isNightMode = !isNightMode;
    update();
  }

  void setSwipeHorizontal() {
    isSwipeHorizontal = !isSwipeHorizontal;
    update();
  }

  void setTotalPages(int totalPages) {
    this.totalPages = totalPages;
    update();
  }

  void setCurrentPages(int currentPage) {
    this.currentPage = currentPage;
    update();
  }

  void setPdfPath(String pdfPath) {
    this.pdfPath = pdfPath;
    update();
  }
}
